//criando um novo elemento no DOM

// const novoElemento=document.createElement('div');
const caixa1=document.querySelector('#caixa1');
//caixa1.appendChild(novoElemento);

//console.log(novoElemento)
//Populando a div 

//novoElemento.innerHTML="Gumercindo"
//inserir id no elemento criado

//novoElemento.setAttribute('id', 'a7');
//novoElemento.setAttribute('class', 'aluno a1');

const alunos=['altamiro', 'brigida', 'cremilda', 'deusdeti', 'eufrasio', 'floriano', 'gumercindo'];
alunos.map((el,valor)=>{
    const novoElemento=document.createElement('div');
    novoElemento.setAttribute('id', 'a' +(valor+1) )
    novoElemento.setAttribute('class', 'aluno a1');
    novoElemento.innerHTML=el;
    caixa1.appendChild(novoElemento)

    //eliminar ou excluir elementos do DOM
    novoElemento.addEventListener('click', ()=>{
       // console.log(evt.target)
       caixa1.removeChild(novoElemento);
    })

})