const caixaAlunos = document.querySelector('#caixaAlunos');
const btn_a = [...document.querySelectorAll(".aluno")];
const a1_2 = document.querySelector("#a1_2");
const alunos = ['Admilson', 'Bráulio', 'Crislaine', 'Demerval', 'Edirlaine', 'Fiona'];
const btnAlunoSelecionado = document.getElementById('btnAlunoSelecionado');
const removerAluno = document.getElementById('btnRemoverAluno');

alunos.map((el, chave) => {
    const novoElemento = document.createElement('div');
    novoElemento.setAttribute('id', 'a' + chave);
    novoElemento.setAttribute('class', 'aluno a1');
    novoElemento.innerHTML = el;

    const comandos = document.createElement('div');
    comandos.setAttribute('class', 'comandos');

    const rb = document.createElement('input');
    rb.setAttribute('type', 'radio');
    rb.setAttribute('name', "rb_aluno");

    comandos.appendChild(rb);

    novoElemento.appendChild(comandos);

    caixaAlunos.appendChild(novoElemento);
})

// //Pegando os radios
// btnAlunoSelecionado.addEventListener('click', (evt) => {

//     const todosRadios = [...document.querySelectorAll('input[type=radio]')];

//     let radioSelecionado = todosRadios.filter((ele) => {

//         return ele.checked;

//     })
//     radioSelecionado = radioSelecionado(0);

//     const AlunoSelecionado = radioSelecionado.parentNode.parentNode.firstChild.textContent;

//     console.log(todosRadios);
//     console.log(radioSelecionado);
//     console.log(AlunoSelecionado);
//     //
//     alert("O aluno selecionado é " +AlunoSelecionado);
// })

//refatorando o código
//botões Aluno Selecionado e Remover Selecionado

const radioSelecionado = () => {
    const todosRadios = [...document.querySelectorAll('input[type=radioSelecionado]')]
    const radioSelecionado = todosRadios.filter((ele) => {
        return ele.checked;
    })

    return radioSelecionado[0];
}

btnAlunoSelecionado.addEventListener('click', (evt) => {
    const rs = radioSelecionado();
    if (rs!=undefined){
        const alunoSelecionado = rs.parentNode.parentNode.firstChild.textContent;
        alert("O aluno selecionado é " +alunoSelecionado);
    }else{
        alert("Selecione um aluno, miserável!!!");
    }
   
})

btnAlunoSelecionadotnRemoverAluno.addEventListener('click', (evt) => {
    const rs = radioSelecionado();
    if (rs!=undefined){
        const alunoSelecionado = rs.parentNode.parentNode;
    alunoSelecionado.remove();
    }else{
        alert("Selecione um aluno, disgraça!!!");
    }
   
})