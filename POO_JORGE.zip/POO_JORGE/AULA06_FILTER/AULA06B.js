const caixaAluno=document.querySelector("#caixaAluno")
const btn_a=[...document.querySelector("aluno")];
const a1_2=document.querySelector('#a1_2')
const alunos=['admilson', 'bráulio', 'demerval', 'crislaine','demerval', 'fiona'];
const btnAlunoSelecionado=document.getElementById('btnAlunoSelecionado');

alunos.map((el,chave)=>{
    const novoElemento=document.createElement('div')
    novoElemento.setAttribute('id','a'+chave);
    novoElemento.setAttribute('class','aluno a1');
    novoElemento.innerHTML=el;

    const comandos=document.createElement('div');
    coamandos.setAttribute('class', 'comandos');
    const rb=document.createElement('input');
    rb.setAttribute('type', 'redio');
    rb.setAttribute('name', 'rb_aluno');

    comandos.appendChild(rb);

    novoElemento.appendChild(comandos);

    caixaAluno.appendChild(novoElemento);

})