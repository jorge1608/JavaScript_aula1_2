function mostrarData(){
    document.getElementById("data").innerHTML = Date();
}
     function mostraMensagem(){
        alert('estou aprendendo programar em js');
         }
